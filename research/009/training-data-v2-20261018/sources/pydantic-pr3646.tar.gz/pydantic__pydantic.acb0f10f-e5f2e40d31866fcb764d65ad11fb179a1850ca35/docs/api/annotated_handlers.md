::: pydantic.annotated_handlers
