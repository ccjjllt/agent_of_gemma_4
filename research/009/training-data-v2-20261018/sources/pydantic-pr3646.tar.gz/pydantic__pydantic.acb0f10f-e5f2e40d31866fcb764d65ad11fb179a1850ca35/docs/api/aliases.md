::: pydantic.aliases
