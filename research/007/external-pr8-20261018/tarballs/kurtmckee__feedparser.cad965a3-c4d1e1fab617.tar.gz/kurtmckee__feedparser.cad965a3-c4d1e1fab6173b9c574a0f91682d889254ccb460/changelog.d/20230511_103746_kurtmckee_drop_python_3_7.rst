Python support
--------------

*   Drop support for Python 3.7.
