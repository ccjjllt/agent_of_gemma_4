.. _implementedservice_config:

.. |start-h3| raw:: html

    <h3>

.. |end-h3| raw:: html

    </h3>

======
config
======

|start-h3| Implemented features for this service |end-h3|

- [ ] associate_resource_types
- [X] batch_get_aggregate_resource_config
  Returns configuration of resource for current regional backend.

        Item is returned in AWS Config format.

        As far a moto goes -- the only real difference between this function
        and the `batch_get_resource_config` function is that this will require
        a Config Aggregator be set up a priori and can search based on resource
        regions.

        Note: moto will IGNORE the resource account ID in the search query.
        

- [X] batch_get_resource_config
  Returns configuration of resource for the current regional backend.

        Item is returned in AWS Config format.

        :param resource_keys:
        :param backend_region:
        

- [X] delete_aggregation_authorization
- [X] delete_config_rule
  Delete config rule used for evaluating resource compliance.

- [X] delete_configuration_aggregator
- [X] delete_configuration_recorder
- [ ] delete_conformance_pack
- [X] delete_delivery_channel
- [ ] delete_evaluation_results
- [ ] delete_organization_config_rule
- [X] delete_organization_conformance_pack
- [ ] delete_pending_aggregation_request
- [ ] delete_remediation_configuration
- [ ] delete_remediation_exceptions
- [ ] delete_resource_config
- [X] delete_retention_configuration
  This will delete the retention configuration if one is present with the provided name.

- [ ] delete_service_linked_configuration_recorder
- [ ] delete_stored_query
- [ ] deliver_config_snapshot
- [ ] describe_aggregate_compliance_by_config_rules
- [ ] describe_aggregate_compliance_by_conformance_packs
- [X] describe_aggregation_authorizations
- [ ] describe_compliance_by_config_rule
- [ ] describe_compliance_by_resource
- [ ] describe_config_rule_evaluation_status
- [X] describe_config_rules
  Return details for the given ConfigRule names or for all rules.

- [ ] describe_configuration_aggregator_sources_status
- [X] describe_configuration_aggregators
- [X] describe_configuration_recorder_status
- [X] describe_configuration_recorders
- [ ] describe_conformance_pack_compliance
- [ ] describe_conformance_pack_status
- [ ] describe_conformance_packs
- [ ] describe_delivery_channel_status
- [X] describe_delivery_channels
- [ ] describe_organization_config_rule_statuses
- [ ] describe_organization_config_rules
- [X] describe_organization_conformance_pack_statuses
- [X] describe_organization_conformance_packs
- [ ] describe_pending_aggregation_requests
- [ ] describe_remediation_configurations
- [ ] describe_remediation_exceptions
- [ ] describe_remediation_execution_status
- [X] describe_retention_configurations
  
        This will return the retention configuration if one is present.

        This should only receive at most 1 name in. It will raise a ValidationException if more than 1 is supplied.
        

- [ ] disassociate_resource_types
- [ ] get_aggregate_compliance_details_by_config_rule
- [ ] get_aggregate_config_rule_compliance_summary
- [ ] get_aggregate_conformance_pack_compliance_summary
- [ ] get_aggregate_discovered_resource_counts
- [ ] get_aggregate_resource_config
- [ ] get_compliance_details_by_config_rule
- [ ] get_compliance_details_by_resource
- [ ] get_compliance_summary_by_config_rule
- [ ] get_compliance_summary_by_resource_type
- [ ] get_conformance_pack_compliance_details
- [ ] get_conformance_pack_compliance_summary
- [ ] get_custom_rule_policy
- [ ] get_discovered_resource_counts
- [ ] get_organization_config_rule_detailed_status
- [X] get_organization_conformance_pack_detailed_status
- [ ] get_organization_custom_rule_policy
- [X] get_resource_config_history
  Returns configuration of resource for the current regional backend.

        Item returned in AWS Config format.

        NOTE: This is --NOT-- returning history as it is not supported in
        moto at this time. (PR's welcome!)

        As such, the later_time, earlier_time, limit, and next_token are
        ignored as this will only return 1 item. (If no items, it raises an
        exception).
        

- [ ] get_resource_evaluation_summary
- [ ] get_stored_query
- [X] list_aggregate_discovered_resources
  Queries AWS Config listing function that must exist for resource backend.

        As far a moto goes -- the only real difference between this function
        and the `list_discovered_resources` function is that this will require
        a Config Aggregator be set up a priori and can search based on resource
        regions.

        :param aggregator_name:
        :param resource_type:
        :param filters:
        :param limit:
        :param next_token:
        :return:
        

- [ ] list_configuration_recorders
- [ ] list_conformance_pack_compliance_scores
- [X] list_discovered_resources
  Queries against AWS Config (non-aggregated) listing function.

        The listing function must exist for the resource backend.

        :param resource_type:
        :param backend_region:
        :param ids:
        :param name:
        :param limit:
        :param next_token:
        :return:
        

- [ ] list_resource_evaluations
- [ ] list_stored_queries
- [X] list_tags_for_resource
  Return list of tags for AWS Config resource.

- [X] put_aggregation_authorization
- [X] put_config_rule
  Add/Update config rule for evaluating resource compliance.

        TBD - Only the "accounting" of config rules are handled at the
        moment.  No events are created or triggered.  There is no
        interaction with the config recorder.
        

- [X] put_configuration_aggregator
- [X] put_configuration_recorder
- [ ] put_conformance_pack
- [X] put_delivery_channel
- [X] put_evaluations
- [ ] put_external_evaluation
- [ ] put_organization_config_rule
- [X] put_organization_conformance_pack
- [ ] put_remediation_configurations
- [ ] put_remediation_exceptions
- [ ] put_resource_config
- [X] put_retention_configuration
  Creates a Retention Configuration.

- [ ] put_service_linked_configuration_recorder
- [ ] put_stored_query
- [ ] select_aggregate_resource_config
- [ ] select_resource_config
- [ ] start_config_rules_evaluation
- [X] start_configuration_recorder
- [ ] start_remediation_execution
- [ ] start_resource_evaluation
- [X] stop_configuration_recorder
- [X] tag_resource
  Add tags in config with a matching ARN.

- [X] untag_resource
  Remove tags in config with a matching ARN.

        If the tags in the tag_keys don't match any keys for that
        ARN, they're just ignored.
        


