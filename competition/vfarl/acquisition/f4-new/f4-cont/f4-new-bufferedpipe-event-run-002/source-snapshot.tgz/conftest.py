# Hermetic test discovery hook for SWE-gemma

